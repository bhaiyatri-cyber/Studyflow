import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Fix composables inside Canvas for PremiumBadgeItem
premium_badge_replacement = """
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val primaryContainer = MaterialTheme.colorScheme.primaryContainer
    
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(80.dp)) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = surfaceVariant,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = premiumSkyBlue,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) primaryContainer else surfaceVariant.copy(alpha=0.5f)),
"""

content = re.sub(
    r'Column\(horizontalAlignment = Alignment\.CenterHorizontally, modifier = Modifier\.width\(80\.dp\)\) \{\s*Box\(\s*modifier = Modifier\.size\(64\.dp\),\s*contentAlignment = Alignment\.Center\s*\) \{\s*Canvas\(modifier = Modifier\.fillMaxSize\(\)\) \{\s*drawArc\(\s*color = MaterialTheme\.colorScheme\.surfaceVariant,\s*startAngle = 0f, sweepAngle = 360f, useCenter = false,\s*style = Stroke\(width = 6\.dp\.toPx\(\), cap = StrokeCap\.Round\)\s*\)\s*if \(currentProgress > 0\) \{\s*drawArc\(\s*color = premiumSkyBlue,\s*startAngle = -90f, sweepAngle = currentProgress \* 360f, useCenter = false,\s*style = Stroke\(width = 6\.dp\.toPx\(\), cap = StrokeCap\.Round\)\s*\)\s*\}\s*\}\s*Box\(\s*modifier = Modifier\s*\.size\(48\.dp\)\s*\.clip\(CircleShape\)\s*\.background\(if \(isUnlocked\) MaterialTheme\.colorScheme\.primaryContainer else MaterialTheme\.colorScheme\.surfaceVariant\.copy\(alpha=0\.5f\)\),',
    premium_badge_replacement.strip(),
    content
)

# And fix AnimatedLinearProgress if it has MaterialTheme inside Canvas
linear_progress_replacement = """
@Composable
fun AnimatedLinearProgress(progress: Float, color: Color) {
    var animationPlayed by remember { mutableStateOf(false) }
    val currentProgress by animateFloatAsState(
        targetValue = if (animationPlayed) progress else 0f,
        animationSpec = tween(durationMillis = 1000),
        label = "linear"
    )
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    LaunchedEffect(key1 = true) { animationPlayed = true }
    Canvas(modifier = Modifier.fillMaxWidth().height(8.dp)) {
        drawRoundRect(
            color = surfaceVariant,
            size = Size(size.width, size.height),
            cornerRadius = CornerRadius(4.dp.toPx())
        )
        drawRoundRect(
            color = color,
            size = Size(size.width * currentProgress, size.height),
            cornerRadius = CornerRadius(4.dp.toPx())
        )
    }
}
"""

content = re.sub(
    r'@Composable\s*fun AnimatedLinearProgress.*?\}\s*\}\s*\}',
    linear_progress_replacement.strip(),
    content,
    flags=re.DOTALL
)

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)

