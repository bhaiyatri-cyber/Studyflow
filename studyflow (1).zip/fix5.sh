# Remove the 3 brackets added at the end of the file
sed -i '$d' app/src/main/java/com/example/ui/screens/HomeScreen.kt
sed -i '$d' app/src/main/java/com/example/ui/screens/HomeScreen.kt
sed -i '$d' app/src/main/java/com/example/ui/screens/HomeScreen.kt

# Insert 3 brackets before @Composable (SectionHeader)
sed -i '/@Composable/!b; /fun SectionHeader/!b; i \    }\n}\n}' app/src/main/java/com/example/ui/screens/HomeScreen.kt
