with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    lines = f.readlines()[891:1274]

count = 0
for line in lines:
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
        
print("Count for 892-1274:", count)
