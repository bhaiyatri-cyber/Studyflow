import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# find start and end of // Premium Single-Card Carousel up to if (currentTask != null) {
start = content.find("// Premium Single-Card Carousel")
end = content.find("if (currentTask != null) {", start)

print("Start index:", start)
print("End index:", end)
print("Length:", end - start)
