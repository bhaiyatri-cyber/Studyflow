import sys

with open("app/src/main/java/com/example/ui/screens/MainScreen.kt", "r") as f:
    content = f.read()

new_content = """package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.viewmodel.StudyViewModel

@Composable
fun MainScreen(
    viewModel: StudyViewModel,
    onNavigateToAddBlock: () -> Unit,
    onNavigateToEditBlock: (Int) -> Unit,
    onNavigateToDetails: (Int) -> Unit,
    onNavigateToSettings: () -> Unit = {}
) {
    val navController = rememberNavController()
    
    Scaffold { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding).consumeWindowInsets(padding)
        ) {
            composable("home") {
                UnifiedMainScreen(
                    viewModel = viewModel,
                    onNavigateToDetails = { onNavigateToDetails(it) },
                    onNavigateToHistory = { navController.navigate("history") },
                    onNavigateToProgress = { navController.navigate("progress") },
                    onNavigateToSchedule = { navController.navigate("schedule") },
                    onNavigateToSettings = onNavigateToSettings
                )
            }
            composable("schedule") {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToDetails = { onNavigateToDetails(it.id) },
                    onNavigateToAddBlock = onNavigateToAddBlock,
                    onNavigateToEditBlock = { onNavigateToEditBlock(it.id) },
                    onNavigateToSettings = onNavigateToSettings,
                    onNavigateToAutoSchedule = { navController.navigate("autoSchedule") },
                    onNavigateToChat = { navController.popBackStack() },
                    onOpenDrawer = { navController.popBackStack() }
                )
            }
            composable("history") {
                HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToDetails = { onNavigateToDetails(it.id) },
                    onNavigateToAssistant = { navController.popBackStack() }
                )
            }
            composable("assistant") {
                AssistantScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("autoSchedule") { AutoScheduleScreen(viewModel, { navController.popBackStack() }) }
            composable("progress") {
                ProgressScreen(viewModel = viewModel, onNavigateBack = { navController.popBackStack() })
            }
        }
    }
}
"""

with open("app/src/main/java/com/example/ui/screens/MainScreen.kt", "w") as f:
    f.write(new_content)
