import sys

with open('app/src/main/java/com/example/ui/screens/AddEditBlockScreen.kt', 'r') as f:
    content = f.read()

repeat_ui = """
            Spacer(modifier = Modifier.height(24.dp))
            Text("Repeat System", style = MaterialTheme.typography.titleMedium)
            var expandedRepeat by remember { mutableStateOf(false) }
            val repeatOptions = listOf("None", "Daily", "Weekly", "Monthly", "Custom")
            var repeatMode by remember { mutableStateOf(block?.repeatMode ?: "None") }
            var customDays by remember { mutableStateOf(block?.customDays ?: "") }

            ExposedDropdownMenuBox(
                expanded = expandedRepeat,
                onExpandedChange = { expandedRepeat = !expandedRepeat }
            ) {
                OutlinedTextField(
                    readOnly = true,
                    value = repeatMode,
                    onValueChange = { },
                    label = { Text("Repeat") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRepeat) },
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expandedRepeat,
                    onDismissRequest = { expandedRepeat = false }
                ) {
                    repeatOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                repeatMode = option
                                expandedRepeat = false
                            }
                        )
                    }
                }
            }
            if (repeatMode == "Custom") {
                Spacer(modifier = Modifier.height(8.dp))
                val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                val selectedDays = customDays.split(",").filter { it.isNotEmpty() }.toMutableList()
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    daysOfWeek.forEachIndexed { index, day ->
                        val dayStr = (index + 1).toString()
                        FilterChip(
                            selected = selectedDays.contains(dayStr),
                            onClick = {
                                if (selectedDays.contains(dayStr)) selectedDays.remove(dayStr)
                                else selectedDays.add(dayStr)
                                customDays = selectedDays.joinToString(",")
                            },
                            label = { Text(day) }
                        )
                    }
                }
            }
"""

if 'Text("Color", style = MaterialTheme.typography.titleMedium)' in content:
    content = content.replace('Text("Color", style = MaterialTheme.typography.titleMedium)', repeat_ui + '\n            Spacer(modifier = Modifier.height(24.dp))\n            Text("Color", style = MaterialTheme.typography.titleMedium)')
else:
    print("Could not find color section")

# Now we need to save the properties in the Save button.
content = content.replace(
    'isPinned = block?.isPinned ?: false',
    'isPinned = block?.isPinned ?: false,\n                            repeatMode = repeatMode,\n                            customDays = customDays,\n                            templateId = block?.templateId'
)

# Fix missing imports
imports = """import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.DropdownMenuItem
"""
content = content.replace('import androidx.compose.material3.Text', imports + 'import androidx.compose.material3.Text')

with open('app/src/main/java/com/example/ui/screens/AddEditBlockScreen.kt', 'w') as f:
    f.write(content)
