import re

with open("temp_progress.txt", "r") as f:
    content = f.read()

# Replace primary color references with premiumSkyBlue
content = content.replace("MaterialTheme.colorScheme.primary", "premiumSkyBlue")
# Replace secondary color references
content = content.replace("MaterialTheme.colorScheme.secondary", "premiumSkyBlue.copy(alpha = 0.6f)")
# Replace the GitHubHeatmap primary parameter
content = content.replace("val primary = premiumSkyBlue", "val premiumSkyBlue = Color(0xFF38BDF8)\n    val primary = premiumSkyBlue")

# Define premiumSkyBlue at the top of ProgressScreen
if "val premiumSkyBlue =" not in content[:2000]:
    content = content.replace("    val allBlocks by viewModel.allBlocks.collectAsState()", "    val allBlocks by viewModel.allBlocks.collectAsState()\n    val premiumSkyBlue = Color(0xFF38BDF8)")

# Define Today's Focus and Lifetime Achievements components
components = """
@Composable
fun AchievementBadge(title: String, icon: ImageVector, color: Color) {
    Card(
        modifier = Modifier
            .size(100.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
"""

if "fun AchievementBadge" not in content:
    content += components

# Inject Today's focus and Lifetime Achievements into the LazyColumn
injection = """
            // Today's Focus Ring & Lifetime Achievements
            if (searchQuery.isEmpty() && selectedFilter == "Today") {
                item {
                    val todayBlocks = evaluatedBlocks.filter { it.startTimeMs >= startOfToday && it.startTimeMs < startOfToday + 24*3600*1000L }
                    val completed = todayBlocks.count { it.status == "Completed" }
                    val total = todayBlocks.size
                    val progress = if (total > 0) completed.toFloat() / total else 0f
                    
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Today's Focus", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedCircularProgress(
                            progress = progress,
                            label = "Tasks Completed",
                            valueText = "$completed / $total",
                            primaryColor = premiumSkyBlue,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        Text("Lifetime Achievements", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            AchievementBadge("7 Day Streak", Icons.Default.LocalFireDepartment, Color(0xFFFF9800))
                            AchievementBadge("100 Hours", Icons.Default.AccessTime, premiumSkyBlue)
                            AchievementBadge("Night Owl", Icons.Default.NightsStay, Color(0xFF7C4DFF))
                            AchievementBadge("Early Bird", Icons.Default.WbSunny, Color(0xFFFFC107))
                        }
                    }
                }
            }
"""

content = content.replace("            // GitHub-style Calendar Heatmap", injection + "\n            // GitHub-style Calendar Heatmap")

with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "w") as f:
    f.write(content)

