import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

target_scaffold = """    Scaffold(
        floatingActionButton = {"""

replacement_scaffold = """    val premiumSkyBlue = Color(0xFF38BDF8)
    val premiumCyan = Color(0xFF22D3EE)
    val premiumColorScheme = darkColorScheme(
        primary = premiumSkyBlue,
        onPrimary = Color.Black,
        primaryContainer = premiumSkyBlue.copy(alpha = 0.2f),
        onPrimaryContainer = premiumSkyBlue,
        secondary = premiumCyan,
        onSecondary = Color.Black,
        secondaryContainer = premiumCyan.copy(alpha = 0.2f),
        onSecondaryContainer = premiumCyan,
        background = Color.Black,
        surface = Color(0xFF111827),
        surfaceVariant = Color(0xFF1F2937),
        onBackground = Color.White,
        onSurface = Color.White,
        onSurfaceVariant = Color(0xFF94A3B8)
    )

    MaterialTheme(colorScheme = premiumColorScheme) {
    Scaffold(
        floatingActionButton = {"""

content = content.replace(target_scaffold, replacement_scaffold)

# also replace the last closing bracket of the HomeScreen function
target_end = """        )
    }
}

@Composable
fun SectionHeader"""

replacement_end = """        )
    }
    } // End of MaterialTheme
}

@Composable
fun SectionHeader"""

content = content.replace(target_end, replacement_end)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
