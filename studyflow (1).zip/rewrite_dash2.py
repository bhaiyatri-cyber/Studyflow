import sys

with open('app/src/main/java/com/example/ui/screens/DashboardScreen.kt', 'w') as f:
    f.write("""package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.TimeBlock
import com.example.ui.viewmodel.StudyViewModel
import java.util.Calendar
import java.util.Collections
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun DashboardScreen(
    viewModel: StudyViewModel,
    onNavigateToDetails: (Int) -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToTab: (String) -> Unit
) {
    val context = LocalContext.current
    val sharedPref = context.getSharedPreferences("dashboard_prefs", Context.MODE_PRIVATE)

    var showCustomizeDialog by remember { mutableStateOf(false) }

    val defaultOrder = listOf(
        "quick_stats", "goal", "ring", "streak", "running", "next", "summary", 
        "hours", "score", "subject", "app_usage", "weekly", "achievements"
    )

    var cardOrder by remember { 
        mutableStateOf(
            sharedPref.getString("card_order", defaultOrder.joinToString(","))!!.split(",").filter { it.isNotBlank() }
        ) 
    }
    
    var cardEnabled by remember {
        mutableStateOf(
            defaultOrder.associateWith { 
                if (sharedPref.contains("card_enabled_$it")) {
                    sharedPref.getBoolean("card_enabled_$it", true)
                } else {
                    it == "running" || it == "next"
                }
            }
        )
    }

    LaunchedEffect(Unit) {
        val savedOrder = sharedPref.getString("card_order", defaultOrder.joinToString(","))!!.split(",").filter { it.isNotBlank() }
        val missing = defaultOrder.filter { !savedOrder.contains(it) }
        cardOrder = savedOrder + missing

        cardEnabled = defaultOrder.associateWith { 
            if (sharedPref.contains("card_enabled_$it")) {
                sharedPref.getBoolean("card_enabled_$it", true)
            } else {
                it == "running" || it == "next"
            }
        }
    }

    val blocks by viewModel.allBlocks.collectAsState()
    val stats by viewModel.stats.collectAsState()

    val now = System.currentTimeMillis()
    val startOfToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val endOfToday = startOfToday + 86400000L

    val todaysBlocks = blocks.filter { it.startTimeMs in startOfToday until endOfToday }
    val completedBlocks = todaysBlocks.filter { it.status == "Completed" }
    
    val todayStudyTimeMs = completedBlocks.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
    val todayStudyHours = todayStudyTimeMs / 3600000f
    
    val currentTask = blocks.find { it.startTimeMs <= now && it.endTimeMs > now && it.status != "Completed" && it.status != "Missed" && it.status != "Skipped" }
    val nextTask = blocks.filter { it.startTimeMs > now && it.status != "Completed" && it.status != "Skipped" && it.status != "Missed" }.minByOrNull { it.startTimeMs }

    val currentSubject = currentTask?.subject ?: nextTask?.subject ?: "None"
    val currentStreak = stats?.currentStreak ?: 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dashboard", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showCustomizeDialog = true }) {
                        Icon(Icons.Default.Tune, contentDescription = "Customize Dashboard")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Smart Dashboard Header
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, bottom = 8.dp)) {
                    Text("Ready to Focus?", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    if (currentTask != null) {
                        Text("You have a task running right now.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                    } else if (nextTask != null) {
                        Text("Your next task is coming up.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Your schedule is clear.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            val categoryMap = mapOf(
                "quick_stats" to "Overview",
                "goal" to "Overview",
                "ring" to "Overview",
                "streak" to "Overview",
                "running" to "Study",
                "next" to "Study",
                "subject" to "Study",
                "hours" to "Analytics",
                "score" to "Analytics",
                "app_usage" to "Analytics",
                "summary" to "Reports",
                "weekly" to "Reports",
                "achievements" to "Reports"
            )

            val activeCards = cardOrder.filter { 
                cardEnabled[it] == true && 
                (it != "running" || currentTask != null) &&
                (it != "next" || nextTask != null)
            }
            
            val groupedCards = mutableMapOf<String, MutableList<String>>()
            activeCards.forEach { cardId ->
                val category = categoryMap[cardId] ?: "Other"
                groupedCards.getOrPut(category) { mutableListOf() }.add(cardId)
            }
            val sortedCategories = groupedCards.keys.sortedBy { category -> 
                activeCards.indexOfFirst { categoryMap[it] == category }
            }

            for (category in sortedCategories) {
                item(key = category) {
                    Column {
                        Text(
                            text = category,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                        val lazyListState = rememberLazyListState()
                        LazyRow(
                            state = lazyListState,
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            flingBehavior = rememberSnapFlingBehavior(lazyListState)
                        ) {
                            items(groupedCards[category]!!) { cardId ->
                                val cardModifier = Modifier.width(280.dp)
                                when (cardId) {
                                    "quick_stats" -> {
                                        Card(
                                            modifier = Modifier.width(320.dp).shadow(4.dp, RoundedCornerShape(20.dp)),
                                            shape = RoundedCornerShape(20.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                        ) {
                                            Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                                QuickStatItem("Today", String.format("%.1fh", todayStudyHours), Icons.Default.Schedule, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                QuickStatItem("Done", "${completedBlocks.size}", Icons.Default.CheckCircle, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                QuickStatItem("Subject", currentSubject.take(6), Icons.AutoMirrored.Filled.MenuBook, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                QuickStatItem("Streak", "$currentStreak", Icons.Default.LocalFireDepartment, Color(0xFFFF6D00), Modifier.weight(1f))
                                            }
                                        }
                                    }
                                    "goal" -> DashboardCard(modifier = cardModifier, title = "Today's Goal", icon = Icons.Default.Flag, onClick = onNavigateToSettings, onAction = {  }) {
                                        Text("Goal: ${stats?.dailyStudyHourGoal ?: 4} Hours / ${stats?.dailyTaskGoal ?: 5} Tasks", style = MaterialTheme.typography.bodyLarge)
                                    }
                                    "ring" -> DashboardCard(modifier = cardModifier, title = "Progress", icon = Icons.Default.DonutLarge, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        val completionRate = if (todaysBlocks.isNotEmpty()) completedBlocks.size.toFloat() / todaysBlocks.size.toFloat() else 0f
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                                            AnimatedCircularProgress(
                                                progress = completionRate,
                                                label = "Completion",
                                                valueText = "${completedBlocks.size} / ${todaysBlocks.size}",
                                                primaryColor = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(100.dp)
                                            )
                                        }
                                    }
                                    "streak" -> DashboardCard(modifier = cardModifier, title = "Current Streak", icon = Icons.Default.LocalFireDepartment, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        Text("$currentStreak Days", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                    }
                                    "running" -> DashboardCard(modifier = cardModifier, title = "Running Task", icon = Icons.Default.PlayCircleFilled, onClick = { currentTask?.let { onNavigateToDetails(it.id) } }, onAction = {}) {
                                        if (currentTask != null) {
                                            Text(currentTask.subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(currentTask.priority, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                    "next" -> DashboardCard(modifier = cardModifier, title = "Next Task", icon = Icons.Default.SkipNext, onClick = { nextTask?.let { onNavigateToDetails(it.id) } }, onAction = {}) {
                                        if (nextTask != null) {
                                            Text(nextTask.subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(nextTask.priority, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                                        }
                                    }
                                    "summary" -> DashboardCard(modifier = cardModifier, title = "Today's Summary", icon = Icons.Default.Summarize, onClick = { onNavigateToTab("history") }, onAction = {}) {
                                        Text("You have completed ${completedBlocks.size} tasks today. Keep it up!", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    "hours" -> DashboardCard(modifier = cardModifier, title = "Study Hours", icon = Icons.Default.Timer, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        Text(String.format("%.1f Hours", todayStudyHours), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                    }
                                    "score" -> DashboardCard(modifier = cardModifier, title = "Focus Score", icon = Icons.Default.Insights, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        val score = if (todaysBlocks.isNotEmpty()) (completedBlocks.size * 100) / todaysBlocks.size else 0
                                        Text("$score%", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                                    }
                                    "subject" -> DashboardCard(modifier = cardModifier, title = "Subject Progress", icon = Icons.AutoMirrored.Filled.MenuBook, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        Text("Top Subject: ${completedBlocks.groupingBy { it.subject }.eachCount().maxByOrNull { it.value }?.key ?: "None"}", style = MaterialTheme.typography.bodyLarge)
                                    }
                                    "app_usage" -> DashboardCard(modifier = cardModifier, title = "App Usage", icon = Icons.Default.Apps, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        Text("App tracking active.", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    "weekly" -> DashboardCard(modifier = cardModifier, title = "Weekly Progress", icon = Icons.Default.DateRange, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        Text("See how you performed this week.", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    "achievements" -> DashboardCard(modifier = cardModifier, title = "Achievements", icon = Icons.Default.EmojiEvents, onClick = { onNavigateToTab("progress") }, onAction = {}) {
                                        Text("Unlocked: ${stats?.totalCompletedTasks ?: 0} Tasks", style = MaterialTheme.typography.bodyLarge)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCustomizeDialog) {
        CustomizeDashboardDialog(
            currentOrder = cardOrder,
            currentEnabled = cardEnabled,
            onDismiss = { showCustomizeDialog = false },
            onSave = { newOrder, newEnabled ->
                cardOrder = newOrder
                cardEnabled = newEnabled
                sharedPref.edit().apply {
                    putString("card_order", newOrder.joinToString(","))
                    newEnabled.forEach { (k, v) -> putBoolean("card_enabled_$k", v) }
                }.apply()
                showCustomizeDialog = false
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DashboardCard(modifier: Modifier = Modifier, title: String, icon: ImageVector, onClick: () -> Unit, onAction: () -> Unit, content: @Composable () -> Unit) {
    var showMenu by remember { mutableStateOf(false) }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = { showMenu = true }
            )
            .shadow(4.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(16.dp))
            content()
            
            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                DropdownMenuItem(text = { Text("Refresh") }, onClick = { showMenu = false })
                DropdownMenuItem(text = { Text("Edit Goal") }, onClick = { showMenu = false })
                DropdownMenuItem(text = { Text("Export Today's Report") }, onClick = { showMenu = false })
                DropdownMenuItem(text = { Text("Dashboard Settings") }, onClick = { showMenu = false })
            }
        }
    }
}

@Composable
fun QuickStatItem(label: String, value: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.aspectRatio(0.85f),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp).fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
            Spacer(modifier = Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
fun CustomizeDashboardDialog(
    currentOrder: List<String>,
    currentEnabled: Map<String, Boolean>,
    onDismiss: () -> Unit,
    onSave: (List<String>, Map<String, Boolean>) -> Unit
) {
    var order by remember { mutableStateOf(currentOrder.toMutableList()) }
    var enabled by remember { mutableStateOf(currentEnabled.toMutableMap()) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text("Customize Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Drag up/down to reorder categories. Toggle to show/hide.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    itemsIndexed(order) { index, item ->
                        val isEnabled = enabled[item] ?: true
                        val title = item.replace("_", " ").replaceFirstChar { it.uppercase() }
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.DragHandle, contentDescription = "Drag", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(4f))
                                Switch(
                                    checked = isEnabled,
                                    onCheckedChange = {
                                         enabled = enabled.toMutableMap().apply { put(item, it) }
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    if (index > 0) {
                                        IconButton(onClick = {
                                            val newOrder = order.toMutableList()
                                            Collections.swap(newOrder, index, index - 1)
                                            order = newOrder
                                        }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up")
                                        }
                                    }
                                    if (index < order.size - 1) {
                                        IconButton(onClick = {
                                            val newOrder = order.toMutableList()
                                            Collections.swap(newOrder, index, index + 1)
                                            order = newOrder
                                        }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = { onSave(order, enabled) }) { Text("Save") }
                }
            }
        }
    }
}
"""
    )
