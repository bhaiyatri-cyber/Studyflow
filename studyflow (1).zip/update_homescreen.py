import sys

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# Fix upcomingTasks
content = content.replace(
    'val upcomingTasks = todaysBlocks.filter { it.startTimeMs > now && it.status != "Completed" }.sortedBy { it.startTimeMs }',
    'val upcomingTasks = todaysBlocks.filter { it.startTimeMs > now && it.status != "Completed" }.sortedWith(compareByDescending<TimeBlock> { it.isPinned }.thenBy { it.startTimeMs })'
)

# Fix Dropdown in TaskCard
# I will use regex or find to inject the Pin option.
import re

dropdown_pattern = r'DropdownMenuItem\(text = { Text\("Duplicate"\) }, onClick = { showMenu = false; onDuplicate\(\) }\)'
pin_option = '''DropdownMenuItem(text = { Text(if (block.isPinned) "Unpin" else "Pin") }, onClick = { showMenu = false; onEdit(block.copy(isPinned = !block.isPinned)) })
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { showMenu = false; onDuplicate() })'''
content = re.sub(dropdown_pattern, pin_option, content)

# 6. Better Empty States
# "Replace empty cards with a premium illustration and "No Tasks Yet / Create Your First Plan" text."
# Let's find "No tasks today."
empty_state_pattern = r'Text\("No tasks today\.", color = MaterialTheme\.colorScheme\.onSurfaceVariant\)'
new_empty_state = '''Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(32.dp)) {
                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(16.dp))
                Text("No Tasks Yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Create Your First Plan", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }'''
content = re.sub(empty_state_pattern, new_empty_state, content)

# same for upcomingTasks?
empty_upcoming_pattern = r'Text\("No upcoming tasks\.", color = MaterialTheme\.colorScheme\.onSurfaceVariant\)'
content = re.sub(empty_upcoming_pattern, new_empty_state, content)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
