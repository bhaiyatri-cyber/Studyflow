with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    text = f.read()

count = 0
for i, char in enumerate(text):
    if char == '{':
        count += 1
    elif char == '}':
        count -= 1
    if count == 0 and char == '}':
        print(f"Top level closed at index {i}, near:")
        print(text[i-50:i+50])
