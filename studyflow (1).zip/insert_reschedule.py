import re

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

reschedule_code = """
            if (isMissed) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Smart Reschedule", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
                    
                    val duration = block.endTimeMs - block.startTimeMs
                    val futureBlocks = blocks.filter { it.endTimeMs > now && it.id != block.id }.sortedBy { it.startTimeMs }
                    var suggestedStart = now + 15 * 60 * 1000L // 15 mins from now
                    for (fb in futureBlocks) {
                        if (suggestedStart + duration <= fb.startTimeMs) {
                            break
                        } else {
                            suggestedStart = maxOf(suggestedStart, fb.endTimeMs + 5 * 60 * 1000L)
                        }
                    }
                    val suggestedEnd = suggestedStart + duration
                    
                    var showRescheduleConfirm by remember { mutableStateOf(false) }
                    
                    if (showRescheduleConfirm) {
                        AlertDialog(
                            onDismissRequest = { showRescheduleConfirm = false },
                            title = { Text("Reschedule Task") },
                            text = { Text("Move task to ${timeFormat.format(Date(suggestedStart))} - ${timeFormat.format(Date(suggestedEnd))}?") },
                            confirmButton = {
                                TextButton(onClick = {
                                    val newBlock = block.copy(startTimeMs = suggestedStart, endTimeMs = suggestedEnd, status = "Upcoming")
                                    viewModel.updateBlock(newBlock)
                                    showRescheduleConfirm = false
                                    onNavigateBack()
                                }) { Text("Confirm") }
                            },
                            dismissButton = {
                                TextButton(onClick = { showRescheduleConfirm = false }) { Text("Cancel") }
                            }
                        )
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(2.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Next Available Slot", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${dateFormat.format(Date(suggestedStart))} at ${timeFormat.format(Date(suggestedStart))} - ${timeFormat.format(Date(suggestedEnd))}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { showRescheduleConfirm = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                            ) {
                                Text("Reschedule Now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
"""

replacement = """
            // 7. Timeline Activity
"""

content = content.replace(replacement, reschedule_code + replacement)

with open('app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
