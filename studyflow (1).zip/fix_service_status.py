import re
with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "r") as f:
    content = f.read()

content = content.replace(
    'val finalStatus = if (studyAppsList.isNotEmpty() && !hasStartedStudying) "Missed" else "Completed"',
    'val finalStatus = if (realStudyTimeMs > 0) "Completed" else "Missed"'
)

with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "w") as f:
    f.write(content)
