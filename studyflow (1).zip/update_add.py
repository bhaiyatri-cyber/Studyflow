import sys
content = open('app/src/main/java/com/example/ui/screens/AddEditBlockScreen.kt').read()

target1 = '''@Composable
fun AddEditBlockScreen(
    block: TimeBlock?,
    onSave: (TimeBlock) -> Unit,
    onDelete: (TimeBlock) -> Unit,
    onNavigateBack: () -> Unit
) {'''
replacement1 = '''@Composable
fun AddEditBlockScreen(
    block: TimeBlock?,
    allBlocks: List<TimeBlock>,
    onSave: (TimeBlock) -> Unit,
    onDelete: (TimeBlock) -> Unit,
    onNavigateBack: () -> Unit
) {'''
content = content.replace(target1, replacement1)

target2 = '''            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("10 mins before start", modifier = Modifier.weight(1f))
                Switch(checked = reminderStart, onCheckedChange = { reminderStart = it })
            }'''
replacement2 = '''            // Conflict Detection
            val conflict = allBlocks.find { 
                it.id != (block?.id ?: -1) && 
                it.status != "Completed" &&
                it.status != "Missed" &&
                startCalendar.timeInMillis < it.endTimeMs && endCalendar.timeInMillis > it.startTimeMs 
            }
            if (conflict != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Default.Warning, contentDescription = "Warning", tint = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            "Time conflict detected with: ${conflict.subject}",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("10 mins before start", modifier = Modifier.weight(1f))
                Switch(checked = reminderStart, onCheckedChange = { reminderStart = it })
            }'''
content = content.replace(target2, replacement2)
content = content.replace('import androidx.compose.material.icons.filled.Warning\n', '')
content = content.replace('import androidx.compose.material.icons.filled.Check', 'import androidx.compose.material.icons.filled.Check\nimport androidx.compose.material.icons.filled.Warning')

open('app/src/main/java/com/example/ui/screens/AddEditBlockScreen.kt', 'w').write(content)
