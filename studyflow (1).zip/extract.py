import json
import sys
import re

transcript_path = "/tmp/workspace/.aistudio/artifacts/brain/79bd9706-0a9a-4e4b-a76a-dc5e7d7825bc/.system_generated/logs/transcript.jsonl"
try:
    with open(transcript_path, "r") as f:
        lines = f.readlines()
except:
    print("Could not open transcript")
    sys.exit(1)

content = ""
for line in reversed(lines):
    if "val tempBlock = TimeBlock(" in line and "AddEditBlockScreen.kt" in line:
        # Find the block where this was printed.
        content = line
        break

if not content:
    print("Could not find content in transcript")
else:
    print("Found something!")
    with open("extracted.txt", "w") as f:
        f.write(content)
