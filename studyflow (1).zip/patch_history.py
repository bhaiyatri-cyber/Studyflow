import sys

with open("app/src/main/java/com/example/ui/screens/HistoryScreen.kt", "r") as f:
    content = f.read()

content = content.replace("fun HistoryScreen(\n    viewModel: StudyViewModel,\n    onNavigateToDetails: (TimeBlock) -> Unit,\n    onNavigateToAssistant: () -> Unit\n)", "fun HistoryScreen(\n    viewModel: StudyViewModel,\n    onNavigateToDetails: (TimeBlock) -> Unit,\n    onNavigateToAssistant: () -> Unit\n)")

content = content.replace("title = { Text(\"History\", fontWeight = FontWeight.Bold) },", """title = { Text("History", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateToAssistant) {
                        Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },""")

# Wait, the actions already have onNavigateToAssistant. So the back button will do the same thing. I'll just change the icon in actions to a search or something, or remove the chat icon since chat is now the home screen.
content = content.replace("""                actions = {
                    IconButton(onClick = onNavigateToAssistant) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Local Assistant", tint = MaterialTheme.colorScheme.primary)
                    }
                },""", "")

with open("app/src/main/java/com/example/ui/screens/HistoryScreen.kt", "w") as f:
    f.write(content)
