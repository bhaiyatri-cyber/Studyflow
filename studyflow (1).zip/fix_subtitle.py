with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "r", encoding="utf-8") as f:
    c = f.read()
c = c.replace('Text("${block.subject} • ${block.status}"', 'Text("${block.notes.takeIf { it.isNotBlank() } ?: "No notes"} • ${block.status}"')
with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "w", encoding="utf-8") as f:
    f.write(c)
