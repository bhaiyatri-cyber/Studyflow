import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Add missing imports for ExperimentalLayoutApi and FlowRow
content = content.replace("import androidx.compose.foundation.layout.*", 
                          "import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.layout.FlowRow\nimport androidx.compose.foundation.layout.ExperimentalLayoutApi")

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)

