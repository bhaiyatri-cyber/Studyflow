import sys

chat_screen_content = """package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.ChatMessage
import com.example.api.generateAiResponse
import com.example.data.local.ChatHistoryManager
import com.example.data.local.ChatSession
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun FlowXLogo(size: Dp = 48.dp, iconSize: Dp = 24.dp) {
    val gradient = Brush.linearGradient(
        colors = listOf(Color(0xFF00C6FF), Color(0xFF0072FF))
    )
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size / 3))
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Default.AutoAwesome,
            contentDescription = "Flow X AI Logo",
            tint = Color.White,
            modifier = Modifier.size(iconSize)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val chatHistoryManager = remember { ChatHistoryManager(context) }
    val coroutineScope = rememberCoroutineScope()
    
    var sessions by remember { mutableStateOf(chatHistoryManager.getSessions().sortedByDescending { it.lastUpdated }) }
    var currentSession by remember { mutableStateOf<ChatSession?>(null) }
    
    // Automatically reopen last active conversation
    LaunchedEffect(Unit) {
        val last = sessions.firstOrNull()
        if (last != null) {
            currentSession = last
        }
    }
    
    var showHistory by remember { mutableStateOf(false) }
    
    if (showHistory) {
        ChatHistoryView(
            sessions = sessions,
            onClose = { showHistory = false },
            onSelectSession = { 
                currentSession = it
                showHistory = false
            },
            onDeleteSession = { session ->
                val newSessions = sessions.filter { it.id != session.id }
                chatHistoryManager.saveSessions(newSessions)
                sessions = newSessions
                if (currentSession?.id == session.id) {
                    currentSession = null
                }
            },
            onRenameSession = { session, newName ->
                val updated = session.copy(title = newName, lastUpdated = System.currentTimeMillis())
                val newSessions = sessions.map { if (it.id == session.id) updated else it }.sortedByDescending { it.lastUpdated }
                chatHistoryManager.saveSessions(newSessions)
                sessions = newSessions
                if (currentSession?.id == session.id) {
                    currentSession = updated
                }
            },
            onClearAll = {
                chatHistoryManager.saveSessions(emptyList())
                sessions = emptyList()
                currentSession = null
            }
        )
        return
    }

    var messages by remember(currentSession) { mutableStateOf(currentSession?.messages ?: emptyList()) }
    var inputText by remember { mutableStateOf("") }
    var isTyping by remember { mutableStateOf(false) }
    
    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current
    
    val profilePrefs = context.getSharedPreferences("local_profile", Context.MODE_PRIVATE)
    val userName = profilePrefs.getString("name", null)
    val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when (currentHour) {
        in 5..11 -> "Good Morning"
        in 12..16 -> "Good Afternoon"
        in 17..20 -> "Good Evening"
        else -> "Good Night"
    }
    
    val welcomeText = if (userName.isNullOrBlank()) "Hello!" else "$greeting, $userName"

    fun saveCurrentSession(newMessages: List<ChatMessage>) {
        if (currentSession == null) {
            val title = newMessages.firstOrNull { it.role == "user" }?.text?.take(30) ?: "New Chat"
            val newSession = ChatSession(title = title, messages = newMessages)
            currentSession = newSession
            val newSessions = (listOf(newSession) + sessions).sortedByDescending { it.lastUpdated }
            chatHistoryManager.saveSessions(newSessions)
            sessions = newSessions
        } else {
            val updated = currentSession!!.copy(messages = newMessages, lastUpdated = System.currentTimeMillis())
            currentSession = updated
            val newSessions = sessions.map { if (it.id == updated.id) updated else it }.sortedByDescending { it.lastUpdated }
            chatHistoryManager.saveSessions(newSessions)
            sessions = newSessions
        }
    }

    fun sendMessage(text: String, retryMessageId: String? = null) {
        if (text.isBlank()) return
        
        val userMsg = ChatMessage(text = text, role = "user")
        
        var currentMessages = messages
        if (retryMessageId == null) {
            currentMessages = currentMessages + userMsg
            messages = currentMessages
            saveCurrentSession(currentMessages)
        }
        
        inputText = ""
        isTyping = true
        
        val historyToPass = currentMessages
        
        coroutineScope.launch {
            if (currentMessages.isNotEmpty()) {
                listState.animateScrollToItem(currentMessages.size - 1)
            }
            
            val fullResponse = generateAiResponse(text, historyToPass)
            isTyping = false
            
            val initialMsg = ChatMessage(text = "", role = "model")
            currentMessages = currentMessages + initialMsg
            messages = currentMessages
            
            if (currentMessages.isNotEmpty()) {
                listState.animateScrollToItem(currentMessages.size - 1)
            }
            
            var currentText = ""
            for (i in fullResponse.indices) {
                currentText += fullResponse[i]
                currentMessages = currentMessages.dropLast(1) + initialMsg.copy(text = currentText)
                messages = currentMessages
                
                kotlinx.coroutines.delay(10)

                if (i % 20 == 0) {
                    listState.animateScrollToItem(currentMessages.size - 1)
                }
            }
            
            saveCurrentSession(currentMessages)
            
            if (currentMessages.isNotEmpty()) {
                listState.animateScrollToItem(currentMessages.size - 1)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FlowXLogo(size = 32.dp, iconSize = 18.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Flow X AI", fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showHistory = true }) {
                        Icon(Icons.Default.History, contentDescription = "History")
                    }
                    IconButton(onClick = { currentSession = null }) {
                        Icon(Icons.Default.Add, contentDescription = "New Chat")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground,
                    actionIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (messages.isEmpty() && !isTyping) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    FlowXLogo(size = 80.dp, iconSize = 48.dp)
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        welcomeText,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "I'm Flow X AI. How can I help you with your study today?",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(messages) { message ->
                        ChatBubble(
                            message = message,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(message.text))
                            },
                            onRetry = {
                                val idx = messages.indexOf(message)
                                var prevUserMsg = ""
                                for (i in idx - 1 downTo 0) {
                                    if (messages[i].role == "user") {
                                        prevUserMsg = messages[i].text
                                        break
                                    }
                                }
                                if (prevUserMsg.isNotEmpty()) {
                                    messages = messages.take(idx)
                                    saveCurrentSession(messages)
                                    sendMessage(prevUserMsg, retryMessageId = message.id)
                                }
                            }
                        )
                    }
                    
                    if (isTyping) {
                        item {
                            TypingIndicator()
                        }
                    }
                }
            }
            
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                        placeholder = { Text("Ask Flow X AI...") },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        maxLines = 3
                    )
                    
                    IconButton(
                        onClick = { sendMessage(inputText) },
                        enabled = inputText.isNotBlank() && !isTyping,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (inputText.isNotBlank() && !isTyping) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (inputText.isNotBlank() && !isTyping) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatHistoryView(
    sessions: List<ChatSession>,
    onClose: () -> Unit,
    onSelectSession: (ChatSession) -> Unit,
    onDeleteSession: (ChatSession) -> Unit,
    onRenameSession: (ChatSession, String) -> Unit,
    onClearAll: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredSessions = sessions.filter { it.title.contains(searchQuery, ignoreCase = true) }
    
    var showClearAllConfirm by remember { mutableStateOf(false) }
    
    if (showClearAllConfirm) {
        AlertDialog(
            onDismissRequest = { showClearAllConfirm = false },
            title = { Text("Clear All Chats") },
            text = { Text("Are you sure you want to delete all chat history? This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    onClearAll()
                    showClearAllConfirm = false
                }) {
                    Text("Clear All", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FlowXLogo(size = 28.dp, iconSize = 16.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Chat History", fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (sessions.isNotEmpty()) {
                        IconButton(onClick = { showClearAllConfirm = true }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                placeholder = { Text("Search chats...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                shape = RoundedCornerShape(16.dp)
            )
            
            if (filteredSessions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No chats found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(filteredSessions) { session ->
                        ChatSessionItem(
                            session = session,
                            onClick = { onSelectSession(session) },
                            onDelete = { onDeleteSession(session) },
                            onRename = { newName -> onRenameSession(session, newName) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatSessionItem(
    session: ChatSession,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onRename: (String) -> Unit
) {
    var showOptions by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    
    if (showRenameDialog) {
        var newTitle by remember { mutableStateOf(session.title) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Chat") },
            text = {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newTitle.isNotBlank()) onRename(newTitle)
                    showRenameDialog = false
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    ListItem(
        headlineContent = { Text(session.title, maxLines = 1, fontWeight = FontWeight.Bold) },
        supportingContent = { 
            Text(
                session.messages.lastOrNull()?.text ?: "Empty chat", 
                maxLines = 1, 
                color = MaterialTheme.colorScheme.onSurfaceVariant
            ) 
        },
        overlineContent = {
            val sdf = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault())
            Text(sdf.format(Date(session.lastUpdated)))
        },
        leadingContent = {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        },
        trailingContent = {
            Box {
                IconButton(onClick = { showOptions = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Options")
                }
                DropdownMenu(
                    expanded = showOptions,
                    onDismissRequest = { showOptions = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        onClick = {
                            showOptions = false
                            showRenameDialog = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete") },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                        onClick = {
                            showOptions = false
                            onDelete()
                        }
                    )
                }
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    onCopy: () -> Unit,
    onRetry: () -> Unit
) {
    val isUser = message.role == "user"
    
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isUser) {
                FlowXLogo(size = 32.dp, iconSize = 18.dp)
                Spacer(modifier = Modifier.width(8.dp))
            }
            
            SelectionContainer {
                Box(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .clip(
                            RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 16.dp
                            )
                        )
                        .background(
                            if (isUser) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = message.text,
                        color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 16.sp
                    )
                }
            }
            
            if (isUser) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("U", color = MaterialTheme.colorScheme.onSecondary, fontWeight = FontWeight.Bold)
                }
            }
        }
        
        if (!isUser) {
            Row(
                modifier = Modifier
                    .padding(start = 40.dp, top = 4.dp)
            ) {
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
                IconButton(
                    onClick = onRetry,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Retry",
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
fun TypingIndicator() {
    Row(
        modifier = Modifier.padding(start = 40.dp, top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "typing")
        
        val alpha1 by infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "dot1"
        )
        
        val alpha2 by infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, delayMillis = 200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "dot2"
        )
        
        val alpha3 by infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, delayMillis = 400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "dot3"
        )
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = alpha1)))
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = alpha2)))
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = alpha3)))
    }
}
"""

with open("app/src/main/java/com/example/ui/screens/ChatScreen.kt", "w") as f:
    f.write(chat_screen_content)
