import sys
with open('app/src/main/java/com/example/ui/screens/SetupScreen.kt', 'r') as f:
    content = f.read()

import re
content = re.sub(r'var hasOverlay by remember \{.*?\}\n', '', content, flags=re.DOTALL)
content = re.sub(r'if \(Build\.VERSION\.SDK_INT >= Build\.VERSION_CODES\.M\) \{\n\s*hasOverlay = Settings\.canDrawOverlays\(context\)\n\s*\}\n', '', content)
content = content.replace('hasNotification && hasAlarm && hasBattery && hasOverlay', 'hasNotification && hasAlarm && hasBattery')
content = re.sub(r'Spacer\(modifier = Modifier\.height\(16\.dp\)\)\n\s*PermissionCard\(\n\s*title = "Popup Alerts",\n\s*description = "Required to show full-screen alerts when a task starts\.",\n\s*icon = Icons\.Default\.Notifications,\n\s*isGranted = hasOverlay,\n\s*onClick = \{.*?\}\n\s*\)\n', '', content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/screens/SetupScreen.kt', 'w') as f:
    f.write(content)
