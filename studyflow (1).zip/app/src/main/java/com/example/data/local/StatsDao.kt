package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DailyStats
import kotlinx.coroutines.flow.Flow

@Dao
interface StatsDao {
    @Query("SELECT * FROM daily_stats WHERE id = 1")
    fun getStats(): Flow<DailyStats?>
    
    @Query("SELECT * FROM daily_stats WHERE id = 1")
    suspend fun getStatsOnce(): DailyStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStats(stats: DailyStats)

    @Update
    suspend fun updateStats(stats: DailyStats)
}
