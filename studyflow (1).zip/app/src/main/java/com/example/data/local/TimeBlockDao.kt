package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TimeBlock
import kotlinx.coroutines.flow.Flow

@Dao
interface TimeBlockDao {
    @Query("SELECT * FROM time_blocks ORDER BY startTimeMs ASC")
    fun getAllBlocks(): Flow<List<TimeBlock>>
    @Query("SELECT * FROM time_blocks ORDER BY startTimeMs ASC")
    suspend fun getAllBlocksSync(): List<TimeBlock>

    @Query("SELECT * FROM time_blocks WHERE id = :id")
    suspend fun getBlockById(id: Int): TimeBlock?

    @Query("SELECT * FROM time_blocks WHERE startTimeMs >= :startOfDay AND startTimeMs <= :endOfDay ORDER BY startTimeMs ASC")
    fun getBlocksForDay(startOfDay: Long, endOfDay: Long): Flow<List<TimeBlock>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlock(timeBlock: TimeBlock): Long

    @Update
    suspend fun updateBlock(timeBlock: TimeBlock)

    @Query("DELETE FROM time_blocks WHERE id = :id")
    suspend fun deleteBlockById(id: Int)
}
