package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "time_blocks")
data class TimeBlock(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val color: Int,
    val iconName: String,
    val reminderBeforeStart: Boolean,
    val reminderBeforeEnd: Boolean,
    val notifyStart: Boolean = true,
    val notifyEnd: Boolean = true,
    val notifyDuring: Boolean = false,
    val status: String, // Upcoming, Running, Completed, Missed
    
    // New premium fields
    val notes: String = "",
    val priority: String = "Medium", // High, Medium, Low
    val createdDateMs: Long = System.currentTimeMillis(),
    val completedOnMs: Long? = null,
    val actualTimeTakenMs: Long? = null,
    val performanceRating: Int? = null, // 1 to 5 stars
    val isPinned: Boolean = false,
    val repeatMode: String = "None", // None, Daily, Weekly, Monthly, Custom
    val customDays: String = "", // e.g. "1,2,3,4,5" for Mon-Fri
    val templateId: Int? = null,
    val studyApps: String = "",
    val appUsageStatsJson: String = "{}"
)
