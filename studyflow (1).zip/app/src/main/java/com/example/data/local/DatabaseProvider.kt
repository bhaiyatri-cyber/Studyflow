package com.example.data.local

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object DatabaseProvider {
    val MIGRATION_4_5 = object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE time_blocks ADD COLUMN isPinned INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE daily_stats ADD COLUMN dailyStudyHourGoal INTEGER NOT NULL DEFAULT 4")
            db.execSQL("ALTER TABLE daily_stats ADD COLUMN dailyTaskGoal INTEGER NOT NULL DEFAULT 5")
        }
    }
    
    val MIGRATION_5_6 = object : Migration(5, 6) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `custom_timers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `hours` INTEGER NOT NULL, `minutes` INTEGER NOT NULL, `seconds` INTEGER NOT NULL, `color` INTEGER NOT NULL, `iconName` TEXT NOT NULL, `notes` TEXT NOT NULL, `useAlarmSound` INTEGER NOT NULL, `useVibration` INTEGER NOT NULL)")
        }
    }
    
    
    val MIGRATION_7_8 = object : Migration(7, 8) {
        override fun migrate(db: SupportSQLiteDatabase) {
            try { db.execSQL("ALTER TABLE time_blocks ADD COLUMN notifyDuring INTEGER NOT NULL DEFAULT 0") } catch(e: Exception) {}
        }
    }

    val MIGRATION_9_10 = object : Migration(9, 10) {
        override fun migrate(db: SupportSQLiteDatabase) {
            try { db.execSQL("ALTER TABLE time_blocks ADD COLUMN appUsageStatsJson TEXT NOT NULL DEFAULT '{}'") } catch(e: Exception) {}
        }
    }

    val MIGRATION_8_9 = object : Migration(8, 9) {
        override fun migrate(db: SupportSQLiteDatabase) {
            try { db.execSQL("ALTER TABLE time_blocks ADD COLUMN studyApps TEXT NOT NULL DEFAULT ''") } catch(e: Exception) {}
        }
    }

    val MIGRATION_6_7 = object : Migration(6, 7) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE time_blocks ADD COLUMN repeatMode TEXT NOT NULL DEFAULT 'None'")
            db.execSQL("ALTER TABLE time_blocks ADD COLUMN customDays TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE time_blocks ADD COLUMN templateId INTEGER DEFAULT NULL")
        }
    }

    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
        return INSTANCE ?: synchronized(this) {
            val instance = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "studyflow-database"
            )
            .addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10)
            .fallbackToDestructiveMigration(true)
            .build()
            INSTANCE = instance
            instance
        }
    }
}
