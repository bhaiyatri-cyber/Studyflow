package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.model.TimeBlock
import com.example.receiver.AlarmReceiver

class AlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleAlarmsForBlock(block: TimeBlock) {
        if (block.status == "Completed" || block.status == "Missed") return
        val now = System.currentTimeMillis()
        if (block.reminderBeforeStart && block.startTimeMs - 10 * 60 * 1000 > now) {
            scheduleAlarm(block, AlarmReceiver.ACTION_REMINDER_START, block.startTimeMs - 10 * 60 * 1000)
        }
        
        if (block.notifyStart) {
            if (block.startTimeMs > now) {
                scheduleAlarm(block, AlarmReceiver.ACTION_START_TASK, block.startTimeMs)
            } else if (block.endTimeMs > now && block.status != "Completed" && block.status != "Missed") {
                scheduleAlarm(block, AlarmReceiver.ACTION_START_TASK, now + 1000)
            }
        }
        
        if (block.notifyDuring) {
            val halfway = block.startTimeMs + (block.endTimeMs - block.startTimeMs) / 2
            if (halfway > now) {
                scheduleAlarm(block, AlarmReceiver.ACTION_REMINDER_DURING, halfway)
            }
        }

        if (block.reminderBeforeEnd && block.endTimeMs - 10 * 60 * 1000 > now) {
            scheduleAlarm(block, AlarmReceiver.ACTION_REMINDER_END, block.endTimeMs - 10 * 60 * 1000)
        }
        
        if (block.notifyEnd) {
            if (block.endTimeMs > now) {
                scheduleAlarm(block, AlarmReceiver.ACTION_END_TASK, block.endTimeMs)
            }
        }
    }

    fun cancelAlarmsForBlock(block: TimeBlock) {
        cancelAlarm(block.id, AlarmReceiver.ACTION_REMINDER_START)
        cancelAlarm(block.id, AlarmReceiver.ACTION_START_TASK)
        
        cancelAlarm(block.id, AlarmReceiver.ACTION_REMINDER_DURING)
        cancelAlarm(block.id, AlarmReceiver.ACTION_REMINDER_END)
        cancelAlarm(block.id, AlarmReceiver.ACTION_END_TASK)
    }

    private fun scheduleAlarm(block: TimeBlock, action: String, timeMs: Long) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            this.action = action
            putExtra(AlarmReceiver.EXTRA_TASK_ID, block.id)
            putExtra(AlarmReceiver.EXTRA_TASK_NAME, block.subject)
            putExtra(AlarmReceiver.EXTRA_TASK_END_TIME, block.endTimeMs)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            block.id + action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    timeMs,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    timeMs,
                    pendingIntent
                )
            }
            Log.d("AlarmScheduler", "Scheduled $action for ${block.subject} at $timeMs")
        } catch (e: SecurityException) {
            Log.e("AlarmScheduler", "Exact alarm permission not granted", e)
        }
    }

    fun scheduleMidnightReset() {
        val calendar = java.util.Calendar.getInstance()
        calendar.add(java.util.Calendar.DAY_OF_YEAR, 1)
        calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
        calendar.set(java.util.Calendar.MINUTE, 0)
        calendar.set(java.util.Calendar.SECOND, 0)
        calendar.set(java.util.Calendar.MILLISECOND, 0)

        val intent = Intent(context, com.example.receiver.MidnightReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            "midnight_reset".hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
            Log.d("AlarmScheduler", "Scheduled Midnight Reset at ${calendar.timeInMillis}")
        } catch (e: SecurityException) {
            Log.e("AlarmScheduler", "Exact alarm permission not granted", e)
        }
    }

    private fun cancelAlarm(blockId: Int, action: String) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            this.action = action
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            blockId + action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
