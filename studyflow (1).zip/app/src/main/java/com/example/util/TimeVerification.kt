package com.example.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

object TimeVerification {
    suspend fun verifyDeviceTime(): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL("https://google.com")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "HEAD"
                connection.connectTimeout = 3000
                connection.readTimeout = 3000
                
                val dateHeader = connection.getHeaderField("Date")
                connection.disconnect()
                
                if (dateHeader != null) {
                    val dateFormat = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US)
                    dateFormat.timeZone = TimeZone.getTimeZone("GMT")
                    val networkDate = dateFormat.parse(dateHeader)
                    if (networkDate != null) {
                        val networkTimeMs = networkDate.time
                        val deviceTimeMs = System.currentTimeMillis()
                        
                        // If difference is more than 5 minutes, consider it incorrect.
                        if (abs(networkTimeMs - deviceTimeMs) > 5 * 60 * 1000) {
                            return@withContext false
                        }
                    }
                }
                true
            } catch (e: Exception) {
                // If internet is unavailable, continue normally
                true
            }
        }
    }
}
