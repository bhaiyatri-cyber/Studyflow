package com.example.util

import com.example.data.model.TimeBlock

object ScheduleStatusEngine {
    fun calculateStatus(block: TimeBlock, currentTimestampMs: Long): String {
        if (block.status == "Completed" || block.status == "Skipped") {
            return block.status
        }
        
        if (currentTimestampMs < block.startTimeMs) {
            return "Upcoming"
        }
        
        if (currentTimestampMs >= block.startTimeMs && currentTimestampMs < block.endTimeMs) {
            if (block.status == "Running") return "Running"
            if (block.studyApps.isNotEmpty()) {
                return "Waiting"
            }
            return "Running" // normal active-task behavior
        }
        
        if (currentTimestampMs >= block.endTimeMs) {
            return "Missed"
        }
        
        return block.status
    }
}

