package com.example.ui.screens

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppItem(val packageName: String, val name: String, val icon: android.graphics.Bitmap?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyAppsScreen(onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val sharedPref = context.getSharedPreferences("studyflow_prefs", Context.MODE_PRIVATE)
    
    var installedApps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var selectedPackages by remember { 
        mutableStateOf(sharedPref.getStringSet("study_apps", emptySet()) ?: emptySet()) 
    }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val apps = packages.filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName.contains("youtube") }
                .map { appInfo ->
                    val name = pm.getApplicationLabel(appInfo).toString()
                    val icon = try {
                        pm.getApplicationIcon(appInfo).toBitmap(100, 100)
                    } catch (e: Exception) { null }
                    AppItem(appInfo.packageName, name, icon)
                }
                .sortedBy { it.name.lowercase() }
            
            withContext(Dispatchers.Main) {
                installedApps = apps
                isLoading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Selected Study Apps", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
                item {
                    Text(
                        "Select the apps you use for studying. Usage time outside these apps will not be counted as actual study time.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                
                items(installedApps) { app ->
                    val isSelected = selectedPackages.contains(app.packageName)
                    ListItem(
                        headlineContent = { Text(app.name) },
                        supportingContent = { Text(app.packageName) },
                        leadingContent = {
                            if (app.icon != null) {
                                Image(bitmap = app.icon.asImageBitmap(), contentDescription = null, modifier = Modifier.size(40.dp))
                            } else {
                                Box(modifier = Modifier.size(40.dp))
                            }
                        },
                        trailingContent = {
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = { checked ->
                                    val newSet = selectedPackages.toMutableSet()
                                    if (checked) newSet.add(app.packageName)
                                    else newSet.remove(app.packageName)
                                    selectedPackages = newSet
                                    sharedPref.edit().putStringSet("study_apps", newSet).apply()
                                }
                            )
                        }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
