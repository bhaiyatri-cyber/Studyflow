package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.model.TimeBlock
import com.example.util.AlarmScheduler
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar

class MidnightReceiver : BroadcastReceiver() {
    @OptIn(DelicateCoroutinesApi::class)
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        Log.d("MidnightReceiver", "Midnight task triggered.")
        val alarmScheduler = AlarmScheduler(context)
        
        GlobalScope.launch {
            try {
                val db = com.example.data.local.DatabaseProvider.getDatabase(context)
                
                val dao = db.timeBlockDao()
                val blocks = dao.getAllBlocks().first()
                
                val calendar = Calendar.getInstance()
                // It's midnight, so today's start is now, yesterday's is -24h
                val yesterdayEnd = calendar.timeInMillis
                val dayOfWeek = if (calendar.get(Calendar.DAY_OF_WEEK) == 1) 7 else calendar.get(Calendar.DAY_OF_WEEK) - 1 // 1=Mon, 7=Sun
                
                // Update incomplete tasks from the past 24 hours to Missed
                val pastTasks = blocks.filter { it.endTimeMs < yesterdayEnd && it.status in listOf("Upcoming", "Waiting", "Running") }
                for (task in pastTasks) {
                    dao.updateBlock(task.copy(status = "Missed"))
                }
                
                // For all blocks that repeat, generate them for today if matching
                val templates = blocks.filter { it.repeatMode != "None" && (it.templateId == null) }
                for (t in templates) {
                    var shouldCreate = false
                    when (t.repeatMode) {
                        "Daily" -> shouldCreate = true
                        "Weekly" -> {
                            val tCal = Calendar.getInstance()
                            tCal.timeInMillis = t.startTimeMs
                            val tDay = if (tCal.get(Calendar.DAY_OF_WEEK) == 1) 7 else tCal.get(Calendar.DAY_OF_WEEK) - 1
                            if (tDay == dayOfWeek) shouldCreate = true
                        }
                        "Monthly" -> {
                            val tCal = Calendar.getInstance()
                            tCal.timeInMillis = t.startTimeMs
                            if (tCal.get(Calendar.DAY_OF_MONTH) == calendar.get(Calendar.DAY_OF_MONTH)) shouldCreate = true
                        }
                        "Custom" -> {
                            val days = t.customDays.split(",").mapNotNull { it.toIntOrNull() }
                            if (days.contains(dayOfWeek)) shouldCreate = true
                        }
                    }
                    if (shouldCreate) {
                        // Offset by days
                        val diffMs = System.currentTimeMillis() - t.startTimeMs
                        val daysDiff = (diffMs / (1000 * 60 * 60 * 24)).toLong() + 1 // roughly
                        
                        // Wait, easier way is to just take template's time and set it to today's date
                        val stCal = Calendar.getInstance()
                        stCal.timeInMillis = t.startTimeMs
                        val enCal = Calendar.getInstance()
                        enCal.timeInMillis = t.endTimeMs
                        
                        val newSt = Calendar.getInstance()
                        newSt.set(Calendar.HOUR_OF_DAY, stCal.get(Calendar.HOUR_OF_DAY))
                        newSt.set(Calendar.MINUTE, stCal.get(Calendar.MINUTE))
                        newSt.set(Calendar.SECOND, 0)
                        
                        val newEn = Calendar.getInstance()
                        newEn.set(Calendar.HOUR_OF_DAY, enCal.get(Calendar.HOUR_OF_DAY))
                        newEn.set(Calendar.MINUTE, enCal.get(Calendar.MINUTE))
                        newEn.set(Calendar.SECOND, 0)
                        
                        if (newEn.before(newSt)) newEn.add(Calendar.DAY_OF_YEAR, 1) // cross midnight
                        
                        val newBlock = t.copy(
                            id = 0,
                            startTimeMs = newSt.timeInMillis,
                            endTimeMs = newEn.timeInMillis,
                            status = "Upcoming",
                            templateId = t.id
                        )
                        val insertedId = dao.insertBlock(newBlock)
                        alarmScheduler.scheduleAlarmsForBlock(newBlock.copy(id = insertedId.toInt()))
                    }
                }
                
                // Reschedule for next midnight
                alarmScheduler.scheduleMidnightReset()
            } catch (e: Exception) {
                Log.e("MidnightReceiver", "Error processing midnight tasks", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
