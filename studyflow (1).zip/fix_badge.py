import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

bad_code = """
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = MaterialTheme.colorScheme.primary,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
"""

good_code = """
            val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
            val primary = MaterialTheme.colorScheme.primary
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = surfaceVariant,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = primary,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
"""

content = content.replace(bad_code.strip(), good_code.strip())

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w', encoding='utf-8') as f:
    f.write(content)

