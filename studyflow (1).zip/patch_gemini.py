import re

with open('app/src/main/java/com/example/api/GeminiApi.kt', 'r') as f:
    content = f.read()

# Update getModels catch block
content = content.replace('''        } catch (e: Exception) {
            // Fallback if network fails fetching models
            selectedModel = "gemini-1.5-flash"
        }''', '''        } catch (e: Exception) {
            if (e is retrofit2.HttpException && e.code() == 429) {
                return@withContext "API rate limit or quota exceeded. Please try again later or check your API key."
            }
            // Fallback if network fails fetching models
            selectedModel = "gemini-1.5-flash"
        }''')

# Update generateContent catch blocks
content = content.replace('''    } catch (e: Exception) {
        if (e is retrofit2.HttpException && e.code() == 404) {''', '''    } catch (e: Exception) {
        if (e is retrofit2.HttpException && e.code() == 429) {
            return@withContext "API rate limit or quota exceeded. Please try again later or check your API key."
        }
        if (e is retrofit2.HttpException && e.code() == 404) {''')

content = content.replace('''            } catch (fallbackEx: Exception) {
                return@withContext "Error: ${fallbackEx.message ?: "Failed to connect to AI"}"
            }
        }
        return@withContext "Error: ${e.message ?: "Failed to connect to AI"}"
    }''', '''            } catch (fallbackEx: Exception) {
                if (fallbackEx is retrofit2.HttpException && fallbackEx.code() == 429) {
                    return@withContext "API rate limit or quota exceeded. Please try again later or check your API key."
                }
                return@withContext "Error: ${fallbackEx.message ?: "Failed to connect to AI"}"
            }
        }
        return@withContext "Error: ${e.message ?: "Failed to connect to AI"}"
    }''')

with open('app/src/main/java/com/example/api/GeminiApi.kt', 'w') as f:
    f.write(content)
