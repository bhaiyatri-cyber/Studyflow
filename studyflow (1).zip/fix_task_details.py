import re
with open("app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt", "r") as f:
    content = f.read()

target = """    if (block == null) {
        LaunchedEffect(Unit) {
            onNavigateBack()
        }
        return
    }"""
replacement = """    if (block == null) {
        return
    }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced!")
else:
    print("Not found!")

with open("app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt", "w") as f:
    f.write(content)
