import re
with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

target = """                if (completedTasks.isNotEmpty()) {
                    item { SectionHeader("Completed", Icons.Default.CheckCircle, MaterialTheme.colorScheme.tertiary) }
                    items(completedTasks) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            isCompleted = true,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = {},
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) },
                            onUpdate = { viewModel.updateBlock(it) }
                        )
                    }
                }"""

replacement = target + """
                if (todaysBlocks.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.EventAvailable, contentDescription = "No tasks", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No tasks scheduled for today.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = onNavigateToAutoSchedule) {
                                Text("Auto Schedule")
                            }
                        }
                    }
                }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced home empty logic")

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
